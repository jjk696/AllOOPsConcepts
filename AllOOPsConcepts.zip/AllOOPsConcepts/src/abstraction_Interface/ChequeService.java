package abstraction_Interface;

import encapsulation.Cheque;

public interface ChequeService {
    void process(Cheque cheque);
    boolean validate(Cheque cheque);
}
