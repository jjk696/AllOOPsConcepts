package abstraction_Interface;

import encapsulation.Cheque;

public class OutstationChequeService implements ChequeService {
    public boolean validate(Cheque cheque) {
        return cheque.getAmount() > 0;
    }

    public void process(Cheque cheque) {
        System.out.println("[Interface] Processing outstation cheque: " + cheque.getChequeNumber());
    }
}