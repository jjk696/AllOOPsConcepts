package abstraction_Interface;

import encapsulation.Cheque;

public class LocalChequeService implements ChequeService {
    public boolean validate(Cheque cheque) {
        return cheque.getAmount() > 0;
    }

    public void process(Cheque cheque) {
        System.out.println("[Interface] Processing local cheque: " + cheque.getChequeNumber());
    }
}
