package polymorphism_methodOverriding;
import encapsulation.Cheque;
import abstraction_Interface.*;
import abstraction_Abstract.*;
import polymorphism_methodOverloading.ChequeValidator;
import inheritance.*;
import inheritance.LocalChequeProcessor;
import inheritance.OutstationChequeProcessor;

public class BankSystem {
    public static void main(String[] args) {
        // Inheritance & Runtime Polymorphism
        Cheque cheque1 = new Cheque("CHQ001", 5000.00, "ACC123");
        Cheque cheque2 = new Cheque("CHQ002", 10000.00, "ACC456");

        ChequeProcessor processor1 = new LocalChequeProcessor();
        ChequeProcessor processor2 = new OutstationChequeProcessor();

        processor1.processCheque(cheque1);
        processor2.processCheque(cheque2);

        // Method Overloading
        Cheque cheque = new Cheque("CHQ001", 10000, "ACC123");
        ChequeValidator validator = new ChequeValidator();
        System.out.println(validator.validateCheque("CHQ001"));
        System.out.println(validator.validateCheque("CHQ001", 10000));
        System.out.println(validator.validateCheque(cheque));

        // Abstraction via Interface
        ChequeService localService = new LocalChequeService();
        ChequeService outstationService = new OutstationChequeService();

        if (localService.validate(cheque1)) localService.process(cheque1);
        if (outstationService.validate(cheque2)) outstationService.process(cheque2);

        // Abstraction via Abstract Class
        AbstractChequeProcessor localProcessor = new abstraction_Abstract.LocalChequeProcessor();
        AbstractChequeProcessor outstationProcessor = new abstraction_Abstract.OutstationChequeProcessor();

        Cheque cheque3 = new Cheque("L99887", 4500, "ACC001");
        Cheque cheque4 = new Cheque("O33221", -100, "ACC002");

        localProcessor.handleCheque(cheque3);
        outstationProcessor.handleCheque(cheque4);
    }
}
