package polymorphism_methodOverloading;

import encapsulation.Cheque;

//methodOverloading Complite time
//Same method name, different parameters
//happens insame class
public class ChequeValidator {

    // Validate using just cheque number
    public boolean validateCheque(String chequeNumber) {
        return chequeNumber != null && chequeNumber.length() == 6;
    }

    // Validate using cheque number and amount
    public boolean validateCheque(String chequeNumber, double amount) {
        return validateCheque(chequeNumber) && amount > 0;
    }

    // Validate full cheque object
    public boolean validateCheque(Cheque cheque) {
        return validateCheque(cheque.getChequeNumber(), cheque.getAmount());
    }
}
