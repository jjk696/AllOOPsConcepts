package inheritance;

import encapsulation.Cheque;

public class OutstationChequeProcessor extends ChequeProcessor {
    @Override
    public void processCheque(Cheque cheque) {
        System.out.println("[Outstation ]Processing outstation cheque with 3-day hold.");
    }
}
