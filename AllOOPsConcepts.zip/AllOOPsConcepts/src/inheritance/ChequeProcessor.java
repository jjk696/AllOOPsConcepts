package inheritance;

import encapsulation.Cheque;

//One class (child/subclass) inherits the properties and methods of another class (parent/superclass).
public class ChequeProcessor {
    public void processCheque(Cheque cheque) {
        System.out.println("[Base ]Processing cheque: " + cheque.getChequeNumber());
    }
}
