package inheritance;

import encapsulation.Cheque;

public class LocalChequeProcessor extends ChequeProcessor {
    @Override
    public void processCheque(Cheque cheque) {
        System.out.println("[Local ]Processing local cheque of amount ₹" + cheque.getAmount());
    }
}
