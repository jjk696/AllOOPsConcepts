package encapsulation;

//Wrapping data (variables) and code (methods) into a single unit (class)
//We want to protect customer and cheque details, so we encapsulate them in classes.

//Fields are private
//Access only through getter methods

public class Cheque {
	
	    private String chequeNumber;
	    private double amount;
	    private String accountNumber;

	    // Constructor
	    public Cheque(String chequeNumber, double amount, String accountNumber) {
	        this.chequeNumber = chequeNumber;
	        this.amount = amount;
	        this.accountNumber = accountNumber;
	    }

	    // Getters and Setters
	    public String getChequeNumber() {
	        return chequeNumber;
	    }

	    public double getAmount() {
	        return amount;
	    }

	    public String getAccountNumber() {
	        return accountNumber;
	    }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
