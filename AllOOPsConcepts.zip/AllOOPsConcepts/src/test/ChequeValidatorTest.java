package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import encapsulation.Cheque;
import polymorphism_methodOverloading.ChequeValidator;

public class ChequeValidatorTest {

    @Test
    public void testValidateByChequeNumber() {
        ChequeValidator validator = new ChequeValidator();
        assertTrue(validator.validateCheque("CHQ001"));
        assertFalse(validator.validateCheque("INVALID"));
    }

    @Test
    public void testValidateByChequeNumberAndAmount() {
        ChequeValidator validator = new ChequeValidator();
        assertTrue(validator.validateCheque("CHQ001", 10000));
        assertFalse(validator.validateCheque("CHQ001", -500));
    }

    @Test
    public void testValidateByChequeObject() {
        ChequeValidator validator = new ChequeValidator();
        Cheque validCheque = new Cheque("CHQ002", 5000, "ACC001");
        Cheque invalidCheque = new Cheque("CHQ002", -200, "ACC002");

        assertTrue(validator.validateCheque(validCheque));
        assertFalse(validator.validateCheque(invalidCheque));
    }
}
