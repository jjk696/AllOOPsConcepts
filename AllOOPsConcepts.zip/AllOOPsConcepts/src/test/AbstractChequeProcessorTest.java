
package test;

import abstraction_Abstract.LocalChequeProcessor;
import abstraction_Abstract.OutstationChequeProcessor;
import encapsulation.Cheque;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AbstractChequeProcessorTest {

    @Test
    void testHandleValidCheque() {
        LocalChequeProcessor processor = new LocalChequeProcessor();
        Cheque cheque = new Cheque("CHQ005", 6000, "ACC000");

        assertDoesNotThrow(() -> processor.handleCheque(cheque));
    }

    @Test
    void testHandleInvalidCheque() {
        OutstationChequeProcessor processor = new OutstationChequeProcessor();
        Cheque cheque = new Cheque("CHQ006", -100, "ACC111");

        assertDoesNotThrow(() -> processor.handleCheque(cheque)); // Still allowed, but prints invalid
    }
}
