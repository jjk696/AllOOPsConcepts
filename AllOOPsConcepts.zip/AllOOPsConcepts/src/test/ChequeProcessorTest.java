package test;

import encapsulation.Cheque;
import inheritance.ChequeProcessor;
import inheritance.LocalChequeProcessor;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

import org.junit.jupiter.api.Test;

class ChequeProcessorTest {

    @Test
    void testLocalChequeProcessing() {
        ChequeProcessor processor = new LocalChequeProcessor();
        Cheque cheque = new Cheque("CHQ003", 3000.0, "ACC123");

        // You can redirect output or just ensure no exception occurs
        assertDoesNotThrow(() -> processor.processCheque(cheque));
    }
}
