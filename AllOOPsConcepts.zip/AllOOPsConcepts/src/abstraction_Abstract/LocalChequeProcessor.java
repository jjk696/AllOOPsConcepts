package abstraction_Abstract;

import encapsulation.Cheque;

public class LocalChequeProcessor extends AbstractChequeProcessor {
    @Override
    protected void processCheque(Cheque cheque) {
        System.out.println("[Abstract] Local cheque " + cheque.getChequeNumber() + " processed.");
    }
}