package abstraction_Abstract;

import encapsulation.Cheque;

public abstract class AbstractChequeProcessor {
    public void handleCheque(Cheque cheque) {
        if (validateAmount(cheque)) {
            processCheque(cheque);
        } else {
            System.out.println("[Abstract] Invalid cheque amount: " + cheque.getAmount());
        }
    }

    protected boolean validateAmount(Cheque cheque) {
        return cheque.getAmount() > 0;
    }

    protected abstract void processCheque(Cheque cheque);
}