package abstraction_Abstract;

import encapsulation.Cheque;

public class OutstationChequeProcessor extends AbstractChequeProcessor {
    @Override
    protected void processCheque(Cheque cheque) {
        System.out.println("[Abstract] Outstation cheque " + cheque.getChequeNumber() + " processed.");
    }
}